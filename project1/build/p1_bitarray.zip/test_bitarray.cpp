#define CATCH_CONFIG_MAIN
#define CATCH_CONFIG_COLOUR_NONE
#include "catch.hpp"

#include <iostream>
#include "BitArray.hpp"

/* Provided test cases */
TEST_CASE( "Bitarray: Test default construction", "[bitarray]" ) {
    BitArray b;  
    REQUIRE(b.size() == 8);
    REQUIRE(b.good());
}

TEST_CASE( "Bitarray: Test construction with asString", "[bitarray]" ) {
    BitArray b;
    REQUIRE(b.asString() == "00000000");
}

TEST_CASE( "Bitarray: Test construction size", "[bitarray]" ) {
    BitArray b(64);
    std::string test_string(64, '0'); // 64-bit array of 0s
    REQUIRE(b.size() == 64);
    REQUIRE(b.good());
    REQUIRE(b.asString() == test_string);
}

TEST_CASE( "Bitarray: Test construction string", "[bitarray]" ) {
    std::string s("00101110000011000001101000001");
    BitArray b(s);
    REQUIRE(b.size() == s.size());
    REQUIRE(b.good());
    REQUIRE(b.asString() == s);
}

TEST_CASE( "Bitarray: Test set", "[bitarray]" ) {
    std::string test_string("10001000");
    BitArray b;
    b.set(3);
    b.set(7);
    REQUIRE(b.size() == 8);
    REQUIRE(b.good());
    REQUIRE(b.asString() == test_string);
}


// My Test Cases

TEST_CASE( "Bitarray: Test reset", "[bitarray]" ) {
    BitArray b;
    b.set(0);
    b.set(7);
    REQUIRE(b.asString() == "10000001");

    b.reset(0);
    REQUIRE(b.good());
    REQUIRE(b.asString() == "10000000");
}

TEST_CASE( "Bitarray: Test toggle", "[bitarray]" ) {
    BitArray b;
    b.toggle(1);
    b.toggle(3);
    REQUIRE(b.good());
    REQUIRE(b.asString() == "00001010");

    b.toggle(3); // toggle back
    REQUIRE(b.asString() == "00000010");
}

TEST_CASE( "Bitarray: Test test()", "[bitarray]" ) {
    BitArray b;
    b.set(2);
    b.set(5);

    REQUIRE(b.test(2));
    REQUIRE(b.test(5));
    REQUIRE_FALSE(b.test(0));
    REQUIRE(b.good());
}

TEST_CASE( "Bitarray: Test invalid index makes bitset invalid", "[bitarray]" ) {
    BitArray b(8);
    REQUIRE(b.good());

    b.set(8);
    REQUIRE_FALSE(b.good());
}

TEST_CASE( "Bitarray: Test invalid size constructor", "[bitarray]" ) {
    BitArray b(0);
    REQUIRE_FALSE(b.good());
    REQUIRE(b.size() == 0);
}